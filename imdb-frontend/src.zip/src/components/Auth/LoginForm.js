import React, { useState } from 'react';
import './Auth.css';

function LoginForm({ onLoginSuccess, onClose }) {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [isRegister, setIsRegister] = useState(false);
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    setIsLoading(true);

    // animation kore ashbe
    setTimeout(() => {
      const userData = {
        id: Date.now(),
        username: formData.email.split('@')[0],
        email: formData.email,
        token: 'fake-jwt-' + Date.now()
      };

      localStorage.setItem('user', JSON.stringify(userData));
      setMessage('Login successful! 🎉 Welcome back!');
      onLoginSuccess(userData);
      
      setTimeout(() => {
        if (onClose) onClose();
        window.location.reload();
      }, 1500);
    }, 1200);
  };

  const handleForgotPassword = () => {
    setMessage('Password reset link sent to your email! 📧');
    setTimeout(() => setMessage(''), 3000);
  };

  const handleClose = () => {
    if (onClose) onClose();
  };

  return (
    <div className="auth-overlay">
      <div className="auth-container">
        
        <button className="close-btn" onClick={handleClose}>×</button>
        
        <div className="auth-header">
          <div className="logo-icon">🎬</div>
          <h1 className="auth-title">
            {isRegister ? 'Join PopCorn' : 'Welcome Back'}
          </h1>
          <p className="auth-subtitle">
            {isRegister 
              ? 'Create your account to save watchlist & ratings' 
              : 'Sign in to continue your cinematic journey'
            }
          </p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              placeholder="your@email.com"
              value={formData.email}
              onChange={handleChange}
              required
              disabled={isLoading}
            />
          </div>
          
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              name="password"
              placeholder="••••••••"
              value={formData.password}
              onChange={handleChange}
              required
              disabled={isLoading}
            />
          </div>

          <button type="submit" className="auth-submit" disabled={isLoading}>
            {isLoading ? 'Signing In...' : (isRegister ? 'Create Account' : 'Sign In')}
          </button>
        </form>


        {message && (
          <div className={`message ${message.includes('successful') ? 'success' : ''}`}>
            {message}
          </div>
        )}

        {!isRegister && (
          <div className="forgot-password">
            <button 
              type="button" 
              className="forgot-btn"
              onClick={handleForgotPassword}
              disabled={isLoading}
            >
              Forgot Password?
            </button>
          </div>
        )}

        <div className="auth-toggle">
          {isRegister ? (
            <>
              Already have an account?{' '}
              <button 
                type="button" 
                className="toggle-btn"
                onClick={() => setIsRegister(false)}
                disabled={isLoading}
              >
                Sign In
              </button>
            </>
          ) : (
            <>
              Still Unregistered?{' '}
              <button 
                type="button" 
                className="toggle-btn"
                onClick={() => setIsRegister(true)}
                disabled={isLoading}
              >
                Create Account
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default LoginForm;
