import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../supabaseClient';
import MovieTrailer from './MovieTrailer';


const MovieDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchMovie() {
      const { data, error } = await supabase
        .from('movies')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        console.error("Error fetching movie:", error);
      } else {
        setMovie(data);
      }
      setLoading(false);
    }

    fetchMovie();
  }, [id]);

  if (loading) return <h2 style={{ color: 'white', textAlign: 'center', marginTop: '50px' }}>Loading...</h2>;
  if (!movie) return <h2 style={{ color: 'white', textAlign: 'center', marginTop: '50px' }}>Movie not found</h2>;

  return (
    <div className="container" style={{ color: 'white', marginTop: '50px', marginBottom: '50px' }}>


      <button
        onClick={() => navigate(-1)}
        className="btn btn-secondary"
        style={{ marginBottom: '20px', padding: '8px 16px' }}
      >
        ← Back
      </button>

      <div className="movie-details-header">
        <h1>{movie.title}</h1>
        {movie.tagline && <p style={{ fontStyle: 'italic', color: '#ccc' }}>"{movie.tagline}"</p>}
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '40px', marginTop: '30px' }}>


        <div style={{ flex: '0 0 300px' }}>
          {movie.poster_path ? (
            <img
              src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
              alt={movie.title}
              style={{ width: '100%', borderRadius: '10px', boxShadow: '0 4px 15px rgba(0,0,0,0.5)' }}
            />
          ) : (
            <div style={{ width: '300px', height: '450px', background: '#333', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>No Image</div>
          )}
        </div>

        {/* INFO SECTION */}
        <div style={{ flex: '1', minWidth: '300px' }}>
          <h3>Overview</h3>
          <p style={{ lineHeight: '1.8', color: '#ddd', fontSize: '1.1rem' }}>
            {movie.overview || "No overview available."}
          </p>
          {/* ekhane add kortesi */}

          <MovieTrailer movieId={movie.tmdb_id} />

          <div style={{ marginTop: '30px', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '15px' }}>
            <p><strong>📅 Release Date:</strong> {movie.release_date || 'Unknown'}</p>
            <p><strong>⭐ Rating:</strong> {movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A'}</p>
            <p><strong>⏳ Runtime:</strong> {movie.runtime ? `${movie.runtime} min` : 'Unknown'}</p>

            {/* 👇 THE FIX: Check if budget exists before calling toLocaleString() */}
            <p><strong>💰 Budget:</strong> {movie.budget ? `$${movie.budget.toLocaleString()}` : 'N/A'}</p>

            {/* Added Revenue check as well just in case */}
            <p><strong>💵 Revenue:</strong> {movie.revenue ? `$${movie.revenue.toLocaleString()}` : 'N/A'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;